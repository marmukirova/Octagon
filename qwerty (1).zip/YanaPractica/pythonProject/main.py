from transformers import pipeline
import re
from docx import Document

# Загрузка модели
print("Loading model...")
pipe = pipeline("fill-mask", model="ai-forever/ruRoberta-large")
print("Model loaded.")

# Кастомный словарь для известных сокращений
abbreviation_dict = {
    "сокр.": "сокращение",
    "сокр": "сокращение",  # добавлен вариант без точки
    "сокр-ие": "сокращение"
}

# Функция для поиска, замены сокращений и применения модели
def find_and_replace_abbreviations(text):
    # Используем уточнённое регулярное выражение для поиска сокращений
    abbreviations = re.findall(r'\bсокр\.?\b|\bсокр-ие\b', text)  # разрешаем точку или отсутствие
    results = []

    for abbr in abbreviations:
        # Проверка для известных сокращений
        if abbr in abbreviation_dict:
            masked_text = text.replace(abbr, "<mask>")
            # Получаем предсказания модели
            predictions = pipe(masked_text)
            results.append({
                "original_text": text,
                "masked_text": masked_text,
                "abbreviation": abbr,
                "predictions": predictions
            })
        else:
            print(f"Сокращение '{abbr}' не найдено в словаре.")
    return results

# Тестовые примеры
test_cases = [
    "Мама мыла р.",  # Простой случай
    "Учитель дал задание прочитать произведение сокр.",  # Сокращение сокр.
    "Сегодня у нас лекция на тему 'Развитие сокр.'",  # Сокращение в контексте
    "На уроке химии мы изучали сокр. кислорода.",  # Сокращение в научном контексте
    "Работа аспиранта по теме 'сокр.' была отправлена на проверку.",  # Академический контекст
    "Сегодня на собрании обсуждали новую стратегию компании и её влияние на сокр.",  # Бизнес-контекст
    "Докладчик из министерства говорил об улучшении условий сокр.",  # Официальная речь
    "На уроке физкультуры преподаватель дал задание сделать 10 подходов к сокр.",  # Спортивный контекст
    "В процессе производства важно следить за качеством продукции и сокр.",  # Производственный контекст
    "Произведение Дарвина о сокр. стало предметом обсуждения."  # Исторический контекст
]

# Создание отчёта
doc = Document()
doc.add_heading("Отчёт по расшифровке текста", level=1)

doc.add_paragraph("Используемая модель: ai-forever/ruRoberta-large")
doc.add_paragraph(
    "Модель ruRoberta-large разработана для работы с текстами на русском языке. "
    "Алгоритм использует mask filling для нахождения наиболее подходящих слов для замены сокращений."
)

doc.add_heading("Примеры работы алгоритма:", level=2)

for i, text in enumerate(test_cases, 1):
    doc.add_heading(f"Пример {i}:", level=3)
    doc.add_paragraph(f"Исходный текст: {text}")

    # Обрабатываем текст
    results = find_and_replace_abbreviations(text)
    if results:
        for result in results:
            doc.add_paragraph(f"Текст после замены: {result['masked_text']}")
            doc.add_paragraph(f"Сокращение: {result['abbreviation']}")
            doc.add_paragraph("Предсказания:")
            for pred in result["predictions"]:
                doc.add_paragraph(f"- {pred['token_str']} (вероятность: {pred['score']:.2f})")
    else:
        doc.add_paragraph("Сокращения не найдены или не удалось найти подходящее слово.")

# Сохранение отчёта
doc.save("report.docx")
print("Отчёт сохранён в report.docx")
